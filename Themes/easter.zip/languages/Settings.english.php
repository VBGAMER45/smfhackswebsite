<?php
// Version: 1.1.2; Settings

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Easter Style Theme for SMF. Features support for major mods built in.';

// Custom Settings for the Easter Style Theme
$txt['keywords'] = 'Keywords:';
$txt['keywords_desc'] = "Keywords to describe your forum"
?>